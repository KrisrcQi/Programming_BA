# This paga is the armory for all functional weapons supporting to main.py targets

def gross_margin_pct(total, gross_income):
    if total == 0:
        return 0
    return (gross_income / total) * 100

def temp_function(row):
    return gross_margin_pct(row["Total"], row["GrossIncome"])


class SalesReport:
    def __init__(self, df): 
        self.df = df 

    def overall_summary(self):
        total_sales = self.df["Total"].sum()
        avg_rating = self.df["Rating"].mean()
        num_transactions = len(self.df)
        
        print("=== Overall Supermarket Summary ===")
        print(f"Total Sales: £{total_sales:.2f}")
        print(f"Average Rating: {avg_rating:.2f}")
        print(f"Number of Transactions: {num_transactions}")
        
    def branch_summary(self, branch_code):
        branch_df = self.df[self.df["Branch"] == branch_code]
    
        total_sales = branch_df["Total"].sum()
        avg_rating = branch_df["Rating"].mean()
        num_transactions = len(branch_df)

        print(f"=== KPIs for Branch {branch_code} ===")
        print(f"Total Sales: £{total_sales:.2f}")
        print(f"Average Rating: {avg_rating:.2f}")
        print(f"Number of Transactions: {num_transactions}")