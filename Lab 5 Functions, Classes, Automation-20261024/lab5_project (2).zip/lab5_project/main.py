import pandas as pd
from functions import date_convert, gross_margin_pct, temp_function
from functions import SalesReport


# 1. load the data
df = pd.read_csv("supermarket_sales.csv")
print(df)
# # optional: convert Date column if present
# if "Date" in df.columns:
#     try:
#         df["Date"] = pd.to_datetime(df["Date"])
#         print('Date datetype has been changed succussfully!')
#     except Exception as e:
#         print("Could not convert Date column:", e)

# 2. compute a grossmargin in pct:
df['GrossMarginPct'] = df.apply(temp_function, axis= 1)
print(df[['Total', 'GrossIncome', 'GrossMarginPct']])


# 3. using class to simplifing our code: 
report = SalesReport(df)
report.overall_summary()
report.branch_summary("A")
report.branch_summary("B")


